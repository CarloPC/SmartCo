import FoodAidProjectionChart from '../components/FoodAidProjectionChart'
import EventAttendanceChart from '../components/EventAttendanceChart'
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Heart, Package, Calendar, Users, AlertCircle,
  Activity, BarChart3, Loader, ArrowRight,
  Sparkles, ShieldCheck, Clock3, MapPin,
} from 'lucide-react'
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts'
import toledoImage from '../assets/Toledo.jpg'
import { useTheme } from '../context/ThemeContext'
import { useAuth } from '../context/AuthContext'
import healthService from '../services/healthService'
import eventsService from '../services/eventsService'
import foodAidService from '../services/foodAidService'
import notificationService from '../services/notificationService'
import purokStatsService from '../services/purokStatsService'
import { getShortPurokName } from '../constants/puroks'

const HomePage = () => {
  const navigate = useNavigate()
  const { isDarkMode } = useTheme()
  const { user } = useAuth()
  const purokLabel = getShortPurokName(user?.purok)

  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({ healthRecords: 0, aidDistributed: 0, upcomingEvents: 0, activeUsers: 0 })
  const [purokHealthStats, setPurokHealthStats] = useState({ total: 0, pending: 0, approved: 0, rejected: 0, monthly: {} })
  const [foodAidStats, setFoodAidStats] = useState({ totalFamilies: 0, familiesServed: 0, pendingDeliveries: 0, completedDeliveries: 0, progress: 0 })
  const [healthTrendsData, setHealthTrendsData] = useState([])
  const [foodAidData, setFoodAidData] = useState([])
  const [eventAttendanceData, setEventAttendanceData] = useState([])
  const [recentAlerts, setRecentAlerts] = useState([])

  useEffect(() => { fetchDashboardData() }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      const purok = user?.purok
      const [healthStats, foodAidItems, events, notifications] = await Promise.all([
        purokStatsService.getHealthStats(purok),
        foodAidService.getFoodAidByPurok(purok),
        eventsService.getEvents(),
        notificationService.getNotifications(),
      ])

      const upcomingEvents = events.filter((e) => e.status === 'upcoming').length

      const totalFamilies = foodAidItems.reduce((s, i) => s + (i.progress?.householdsTarget ?? i.totalFamilies ?? 0), 0)
      const familiesServed = foodAidItems.reduce((s, i) => s + (i.progress?.householdsServed ?? i.deliveredFamilies ?? 0), 0)
      const pendingDeliveries = foodAidItems.filter((i) => !['completed', 'archived', 'cancelled'].includes(i.progress?.workflowStatus)).length
      const completedDeliveries = foodAidItems.filter((i) => ['completed', 'archived'].includes(i.progress?.workflowStatus)).length

      setStats({ healthRecords: healthStats.total, aidDistributed: familiesServed, upcomingEvents, activeUsers: 342 })
      setPurokHealthStats(healthStats)
      setFoodAidStats({
        totalFamilies,
        familiesServed,
        pendingDeliveries,
        completedDeliveries,
        progress: totalFamilies > 0 ? Math.round((familiesServed / totalFamilies) * 100) : 0,
      })
      setHealthTrendsData(processHealthMonthlyTrend(healthStats.monthly))
      setFoodAidData(processFoodAidTrend(foodAidItems))
      setEventAttendanceData(processEventAttendance(events))
      // Priority Alerts: emergencies always sort first — otherwise 5 newer
      // non-emergency notifications could push an active emergency out of
      // the top-5 slice entirely. Recency still governs ordering within
      // each group (emergencies vs everything else).
      const alerts = [...notifications]
        .sort((a, b) => {
          const aEmergency = a.type === 'emergency' ? 1 : 0
          const bEmergency = b.type === 'emergency' ? 1 : 0
          if (aEmergency !== bEmergency) return bEmergency - aEmergency
          return new Date(b.createdAt) - new Date(a.createdAt)
        })
        .slice(0, 5)
        .map((n) => ({ id: n.id, type: n.category, message: n.message, time: getRelativeTime(n.createdAt), urgent: n.type === 'emergency' }))
      setRecentAlerts(alerts)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  // Last 6 months of purok-wide checkup counts, from the privacy-safe
  // aggregate stats — no individual health records are ever fetched here.
  const processHealthMonthlyTrend = (monthly = {}) => {
    const now = new Date()
    return Array.from({ length: 6 }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      return { date: d.toLocaleDateString('en-US', { month: 'short' }), checkups: monthly[key] || 0 }
    })
  }

  // Groups this purok's food aid distributions by month for the trend chart.
  const processFoodAidTrend = (items) => {
    const map = {}
    items.forEach((item) => {
      const d = item.date ? new Date(item.date) : new Date(item.createdAt || Date.now())
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      if (!map[key]) map[key] = { key, period: d.toLocaleDateString('en-US', { month: 'short' }), families: 0, delivered: 0 }
      map[key].families += item.progress?.householdsTarget ?? item.totalFamilies ?? 0
      map[key].delivered += item.progress?.householdsServed ?? item.deliveredFamilies ?? 0
    })
    return Object.values(map).sort((a, b) => a.key.localeCompare(b.key))
  }

  const processEventAttendance = (events) => {
    const map = {}
    events.forEach((e) => {
      const c = e.category || 'Other'
      if (!map[c]) map[c] = { category: c, expected: 0, actual: 0 }
      map[c].expected += e.expectedAttendees || 0
      map[c].actual += e.attendees?.length || 0
    })
    return Object.values(map)
  }

  const getRelativeTime = (timestamp) => {
    const diff = Math.floor((new Date() - new Date(timestamp)) / 1000)
    if (diff < 60) return 'Just now'
    if (diff < 3600) return `${Math.floor(diff / 60)} mins ago`
    if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`
    return `${Math.floor(diff / 86400)} days ago`
  }

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null
    return (
      <div className="rounded-xl border border-white/25 bg-indigo-900/70 p-3 shadow-lg backdrop-blur-xl">
        <p className="mb-1 text-xs font-bold text-white/60 uppercase tracking-wider">{label}</p>
        {payload.map((entry, i) => (
          <p key={i} className="text-xs font-semibold" style={{ color: entry.color }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    )
  }

  const totalFamilies = foodAidStats.totalFamilies
  const totalDelivered = foodAidStats.familiesServed
  const deliveryProgress = foodAidStats.progress
  const totalExpected = eventAttendanceData.reduce((s, i) => s + i.expected, 0)
  const totalActual = eventAttendanceData.reduce((s, i) => s + i.actual, 0)
  const attendanceRate = totalExpected > 0 ? ((totalActual / totalExpected) * 100).toFixed(1) : 0
  const greeting = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 18 ? 'Good afternoon' : 'Good evening'

  /* glass card — used on every panel */
 const card =
  'rounded-2xl border border-white/20 bg-gradient-to-br from-white/20 via-white/10 to-white/5 shadow-2xl backdrop-blur-xl ring-1 ring-white/10 transition-all duration-300 hover:border-white/40 hover:shadow-blue-500/10'
  const statCards = [
  {
    icon: Heart,
    label: 'Health Records',
    value: stats.healthRecords,
    iconBg:
      'bg-gradient-to-br from-rose-500 via-pink-500 to-red-500',
    iconColor: 'text-white',
    iconRing: 'ring-rose-300/40',
  },
  {
    icon: Package,
    label: 'Families Served',
    value: stats.aidDistributed,
    iconBg:
      'bg-gradient-to-br from-emerald-500 via-green-500 to-teal-500',
    iconColor: 'text-white',
    iconRing: 'ring-emerald-300/40',
  },
  {
    icon: Calendar,
    label: 'Upcoming Events',
    value: stats.upcomingEvents,
    iconBg:
      'bg-gradient-to-br from-violet-500 via-purple-500 to-fuchsia-500',
    iconColor: 'text-white',
    iconRing: 'ring-violet-300/40',
  },
  {
    icon: Users,
    label: 'Active Users',
    value: stats.activeUsers,
    iconBg:
      'bg-gradient-to-br from-amber-400 via-orange-400 to-yellow-500',
    iconColor: 'text-white',
    iconRing: 'ring-amber-300/40',
  },
]

  const quickActions = [
  {
    label: 'Record Checkup',
    description: 'Log a new resident health update',
    path: '/health',
    icon: Heart,
    gradient: 'from-sky-500/60 via-blue-500/40 to-cyan-600/25',
    glow: 'hover:shadow-sky-500/30',
  },

  ...(user?.role === 'admin' || user?.role === 'barangay_official'
    ? [{
        label: 'Schedule Aid',
        description: 'Plan next food aid distribution',
        path: '/food-aid/optimize',
        icon: Package,
        gradient: 'from-emerald-500/60 via-green-500/40 to-teal-600/25',
        glow: 'hover:shadow-emerald-500/30',
      }]
    : []),

  {
    label: 'Check Event',
    description: 'Publish a barangay activity',
    path: '/events',
    icon: Calendar,
    gradient: 'from-violet-500/60 via-fuchsia-500/40 to-purple-700/25',
    glow: 'hover:shadow-violet-500/30',
  },

  {
    label: 'Report Emergency',
    description: 'Send a fast community alert',
    path: '/emergency/report',
    icon: AlertCircle,
    gradient: 'from-rose-500/60 via-red-500/40 to-orange-600/25',
    glow: 'hover:shadow-rose-500/30',
  },
]

  if (loading) {
    return (
      <div className="min-h-screen relative">
        <div className="fixed inset-0 bg-cover bg-center -z-10" style={{ backgroundImage: `url(${toledoImage})` }}>
          <div className={`absolute inset-0 ${isDarkMode
            ? 'bg-gradient-to-br from-slate-900/95 via-blue-950/95 to-indigo-950/95'
            : 'bg-gradient-to-br from-blue-600/90 via-indigo-600/90 to-blue-800/90'}`}
          />
        </div>
        <div className="flex min-h-[80vh] items-center justify-center">
          <div className={`${card} px-8 py-10 text-center`}>
            <Loader className="mx-auto mb-4 h-10 w-10 animate-spin text-white" />
            <p className="font-semibold text-white">Loading your community dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 bg-cover bg-center -z-10" style={{ backgroundImage: `url(${toledoImage})` }}>
        <div className={`absolute inset-0 ${isDarkMode
          ? 'bg-gradient-to-br from-slate-900/95 via-blue-950/95 to-indigo-950/95'
          : 'bg-gradient-to-br from-blue-600/90 via-indigo-600/90 to-blue-800/90'}`}
        />
      </div>

      {/* Decorative blobs */}
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-blue-400/20 blur-3xl" />
        <div className="absolute top-1/3 right-0 h-80 w-80 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-violet-500/15 blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '32px 32px' }}
        />
      </div>

      <div className="mx-auto max-w-7xl space-y-5 p-4 sm:space-y-6 sm:p-6 lg:p-8">

      {/* —— Hero welcome banner —— */}
     <section
  className={`${card} overflow-hidden bg-gradient-to-r from-indigo-500/30 via-violet-500/20 to-blue-500/30`}
>
        <div className="flex flex-col gap-6 p-5 sm:p-7 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 hover:bg-white/20 px-3 py-1 text-xs font-semibold text-white backdrop-blur-sm">
              <Sparkles className="h-3.5 w-3.5 text-yellow-300" />
              AI-powered barangay overview
            </div>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-white sm:text-4xl">
              {greeting}, {user?.fullName?.split(' ')[0] || 'there'} 😊
            </h2>
            <p className="mt-2 text-sm leading-6 text-white/70 sm:text-base">
              Keep tabs on health updates, food aid progress, and Barangay Ilihan events — all in one modern dashboard.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <button
                onClick={() => navigate('/health')}
                className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 px-5 py-2.5 text-white shadow-lg hover:from-blue-600 hover:to-indigo-700 text-sm font-bold text-indigo-700 shadow-md transition hover:bg-indigo-50 hover:shadow-lg"
              >
                Record checkup <ArrowRight className="h-4 w-4" />
              </button>
              <button
                onClick={() => navigate('/notifications')}
                className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 hover:bg-white/20 px-5 py-2.5 text-sm font-semibold text-white backdrop-blur-sm transition hover:bg-white/25"
              >
                Review alerts
              </button>
            </div>
          </div>

          {/* At-a-glance mini panel */}
          <div className="flex w-full max-w-xs flex-col gap-3 lg:w-auto">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold uppercase tracking-widest text-white/50">Today at a glance</p>
              <span className="flex items-center gap-1.5 rounded-full bg-emerald-400/20 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />Live
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-white/30 bg-gradient-to-br from-blue-500/25 to-cyan-500/10 p-4 backdrop-blur-sm">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-200">
                  <ShieldCheck className="h-3.5 w-3.5" /> Coverage
                </div>
                <p className="mt-2 text-2xl font-bold text-white">{deliveryProgress}%</p>
              </div>
              <div className="rounded-xl border border-white/30 bg-gradient-to-br from-violet-500/25 to-purple-500/10 p-4 backdrop-blur-sm">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-violet-200">
                  <Clock3 className="h-3.5 w-3.5" /> Attendance
                </div>
                <p className="mt-2 text-2xl font-bold text-white">{attendanceRate}%</p>
              </div>
            </div>
            <p className="text-center text-xs text-white/40">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </p>
          </div>
        </div>
      </section>

      {/* —— Stat cards —— */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {statCards.map((c) => (
          <div
  key={c.label}
  className={`${card} p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_20px_60px_rgba(59,130,246,.25)] hover:border-white/40`}
>
            <div
  className={`mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl shadow-xl ring-2 transition-transform duration-300 group-hover:scale-110 ${c.iconBg} ${c.iconRing}`}
>
              <c.icon className={`h-5 w-5 ${c.iconColor}`} />
            </div>
            <div className="text-3xl font-bold tracking-tight text-white">{c.value}</div>
            <div className="mt-1 text-xs font-semibold uppercase tracking-widest text-white/50">{c.label}</div>
          </div>
        ))}
      </section>

      {/* —— Health trend + Alerts —— */}
      <section className="grid grid-cols-1 gap-5 xl:grid-cols-[1.4fr_0.9fr]">

        <div className={`${card} p-5 lg:p-6`}>
          <div className="mb-5 flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/20 bg-gradient-to-br from-sky-500 to-blue-600 shadow-lg shadow-sky-500/30">
              <Activity className="h-4 w-4 text-sky-200" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white/50">{purokLabel} health trend</p>
              <p className="text-base font-semibold text-white">Monthly checkup trend</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={healthTrendsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.5)' }} stroke="rgba(255,255,255,0.1)" />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.5)' }} stroke="rgba(255,255,255,0.1)" />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '12px', color: 'rgba(255,255,255,0.6)' }} iconType="line" />
              <Line type="monotone" dataKey="checkups" stroke="#93c5fd" strokeWidth={2.5} name="Checkups" dot={{ fill: '#93c5fd', r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <div className="rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-center">
              <p className="text-lg font-bold text-white">{purokHealthStats.pending}</p>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-white/50">Pending</p>
            </div>
            <div className="rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-center">
              <p className="text-lg font-bold text-white">{purokHealthStats.approved}</p>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-white/50">Approved</p>
            </div>
            <div className="rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-center">
              <p className="text-lg font-bold text-white">{purokHealthStats.rejected}</p>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-white/50">Rejected</p>
            </div>
          </div>
        </div>

        <div className={`${card} p-5 lg:p-6`}>
          <div className="mb-5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/20 bg-gradient-to-br from-rose-500 to-red-600 shadow-lg shadow-rose-500/30">
                <AlertCircle className="h-4 w-4 text-rose-200" />
              </div>
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-white/50">Priority alerts</p>
                <p className="text-base font-semibold text-white">Latest updates</p>
              </div>
            </div>
            <button onClick={() => navigate('/notifications')} className="text-xs font-bold uppercase tracking-wider text-blue-200 transition hover:text-white">
              View all
            </button>
          </div>
          {recentAlerts.length > 0 ? (
            <div className="space-y-2">
              {recentAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className={
                    alert.urgent
                      ? 'relative flex items-start gap-3 rounded-xl border border-rose-400/60 bg-rose-500/15 px-3 py-3 shadow-[0_0_18px_rgba(244,63,94,0.35)] ring-1 ring-rose-400/30 animate-[pulse-glow_2s_ease-in-out_infinite]'
                      : 'flex items-start gap-3 border-b border-white/10 px-1 py-3 last:border-0'
                  }
                >
                  <span className={`mt-1.5 h-2 w-2 flex-shrink-0 rounded-full ${alert.urgent ? 'animate-pulse bg-rose-400 shadow-[0_0_8px_rgba(244,63,94,0.9)]' : 'bg-white/30'}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start gap-2">
                      <p className={`text-sm leading-5 ${alert.urgent ? 'font-bold text-white' : 'font-medium text-white'}`}>{alert.message}</p>
                      {alert.urgent && (
                        <span className="flex-shrink-0 animate-pulse rounded-full border border-rose-300/40 bg-rose-500/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-100">
                          🚨 Urgent
                        </span>
                      )}
                    </div>
                    <div className={`mt-1 flex items-center gap-1 text-xs ${alert.urgent ? 'text-rose-200/80' : 'text-white/40'}`}>
                      <MapPin className="h-3 w-3" />{alert.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-white/20 p-5 text-center text-sm text-white/40">
              No recent alerts. New notifications will appear here.
            </div>
          )}
        </div>
      </section>

      {/* —— Charts —— */}
      <section className="grid grid-cols-1 gap-5 xl:grid-cols-2">

        <div className={`${card} p-5 lg:p-6`}>
          <div className="mb-5 flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/20 bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg shadow-emerald-500/30">
              <Package className="h-4 w-4 text-emerald-200" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white/50">{purokLabel} food aid distribution</p>
              <p className="text-base font-semibold text-white">{deliveryProgress}% of families reached</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={foodAidData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="period"   tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.5)' }} stroke="rgba(255,255,255,0.1)" />
              <YAxis                    tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.5)' }} stroke="rgba(255,255,255,0.1)" />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '12px', color: 'rgba(255,255,255,0.6)' }} iconType="rect" />
              <Area type="monotone" dataKey="families"  stroke="#6ee7b7" fill="#6ee7b7" fillOpacity={0.15} name="Families"  strokeWidth={2} />
              <Area type="monotone" dataKey="delivered" stroke="#34d399" fill="#34d399" fillOpacity={0.35} name="Delivered" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
          <div className="mt-3 rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-xs text-white/60">
            <span className="font-semibold text-white">Progress:</span> {totalDelivered} of {totalFamilies} families served
            <span className="mx-1.5 text-white/30">•</span>
            {foodAidStats.pendingDeliveries} pending, {foodAidStats.completedDeliveries} completed
          </div>
        </div>

        <div className={`${card} p-5 lg:p-6`}>
          <div className="mb-5 flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/20 bg-gradient-to-br from-violet-500 to-purple-600 shadow-lg shadow-violet-500/30">
              <BarChart3 className="h-4 w-4 text-violet-200" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white/50">Event attendance</p>
              <p className="text-base font-semibold text-white">{attendanceRate}% overall turnout</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={eventAttendanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.5)' }} stroke="rgba(255,255,255,0.1)" />
              <YAxis                    tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.5)' }} stroke="rgba(255,255,255,0.1)" />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '12px', color: 'rgba(255,255,255,0.6)' }} iconType="rect" />
              <Bar dataKey="expected" fill="rgba(167,139,250,0.5)" name="Expected" radius={[6, 6, 0, 0]} />
              <Bar dataKey="actual"   fill="#a78bfa"              name="Actual"   radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-3 rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-xs text-white/60">
            <span className="font-semibold text-white">Attendance:</span> {totalActual} of {totalExpected} expected participants
          </div>
        </div>
      </section>

      {/* —— Quick actions —— */}
      <section
  className={`${card} bg-gradient-to-br from-indigo-500/15 via-blue-500/10 to-violet-500/15 p-5 lg:p-6`}
>
        <div className="mb-5">
          <p className="text-xs font-bold uppercase tracking-wider text-white/50">Quick actions</p>
          <p className="mt-0.5 text-base font-semibold text-white">Jump into the most-used tasks</p>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {quickActions.map((action) => {
            const Icon = action.icon
            return (
              <button
  key={action.label}
  onClick={() => navigate(action.path)}
  className={`
group
relative
overflow-hidden
rounded-3xl
border
${action.border}
bg-gradient-to-br
${action.gradient}
p-5
text-left
backdrop-blur-xl
shadow-xl
transition-all
duration-500
hover:-translate-y-2
hover:scale-[1.04]
hover:shadow-[0_20px_80px_rgba(0,0,0,.35)]
`}
>

  {/* Glow */}
  <div
    className="
absolute
-inset-20
opacity-40
blur-3xl
group-hover:opacity-70
transition-all
duration-500
bg-gradient-to-br
from-white/20
to-transparent
"
  />

  {/* Shine */}
  <div
    className="
absolute
inset-0
opacity-0
group-hover:opacity-100
transition
duration-700
bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.25),transparent_55%)]
"
  />

  <div className="relative z-10">

    <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 border border-white/20 backdrop-blur-xl shadow-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-6">
      <Icon className="h-5 w-5 text-white" />
    </div>

    <p className="font-bold text-white">
      {action.label}
    </p>

    <p className="mt-2 text-sm text-white/70">
      {action.description}
    </p>

    <div className="mt-5 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white/70 group-hover:text-white">
      OPEN
      <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
    </div>

  </div>

</button>
            )
          })}
        </div>
      </section>

      </div>
    </div>
  )
}

export default HomePage